export const ModuleActionTypes = {
    INC_MODULE_ID: "INC_MODULE_ID",
    DEC_MODULE_ID: "DEC_MODULE_ID",
    SELECT_MODULE_ID: "SELECT_MODULE_ID",
  };
  