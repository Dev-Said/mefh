export const DejaSuiviActionTypes = {
    DEJA_SUIVI: "DEJA_SUIVI",
  };
  