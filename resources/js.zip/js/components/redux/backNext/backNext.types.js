export const BackNextActionTypes = {
    GET_BACKNEXT: "GET_BACKNEXT",
  };
  