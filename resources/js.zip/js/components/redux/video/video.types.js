export const VideosActionTypes = {
    GET_VIDEO: "GET_VIDEO",
  };
  