export const TitreChapitreActionTypes = {
    GET_TITRECHAPITRE: "GET_TITRECHAPITRE",
  };
  