export const ActiveStepActionTypes = {
    ACTIVE_STEP_UPDATE: "ACTIVE_STEP_UPDATE",
  };
  