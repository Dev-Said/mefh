export const ChapitreActionTypes = {
  GET_CHAPITRE: "GET_CHAPITRE",
};
