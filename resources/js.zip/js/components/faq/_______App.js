import React from 'react';
import ReactDOM from 'react-dom';
import Faq from './faq';



ReactDOM.render(
<div>
  <Faq />
</div>,
  document.getElementById('faq') 
);
 

